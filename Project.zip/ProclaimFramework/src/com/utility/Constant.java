package com.utility;

public class Constant {
	    public static final String URL = "http://10.155.8.141:8095/Claims/login.action";
	    public static final String Username = "INOS004078";
	    public static final String Password ="Jul@2017";
		public static final String Path_TestData = "C://Selenium_Workspace//ProclaimFramework//src//com//testData//";
		public static final String File_TestData = "TestData.xlsx";
		
		//TestCases Sheet Columns
		public static final int Col_TestCaseName = 0;	
		public static final int Col_Testcase_Discription = 1;
		public static final int Col_Execution = 2;
		public static final int Col_Browser = 3;
		public static final int Col_Result = 4;
		
		//TestSheet Columns
		public static final int Col_TestCase_ID = 0;	
		public static final int Col_Step_ID = 1;
		public static final int Col_Step_Discription = 2;
		public static final int Col_UserName = 3;
		public static final int Col_Password = 4;
		public static final int Col_result = 5;
	
		//Path for Screenshot
		public static final String Path_ScreenShot = "C://Selenium_Workspace//ProclaimFramework//src//com//Screenshot//";
	
		//Driver binary path
		public static final String Driver_Path = "C://Selenium_Workspace//ProclaimFramework//src//com//Drivers//";
		public static final String Gecko_Driver = "geckodriver.exe";
		public static final String IE_Driver = "IEDriverServer.exe";
		public static final String Chrome_Driver = "chromedriver.exe";
	}
