package com.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.utility.Log;

public class LogIn_Page extends BaseClass 
{
	public LogIn_Page(WebDriver driver) 
	{
		super(driver);
	}

	private static WebElement element = null;
	
	public static WebElement Username() throws Exception
	{
		try {
				element = driver.findElement(By.id("userId"));
				Log.info("Username text box is found on the Login Page");
			} 
		catch (Exception e) 
			{
				Log.error("UserName text box is not found on the Login Page");
			throw(e);
			}
		
		return element;
		
	}
	
	public static WebElement txtPassword() throws Exception 
	{
		try {
				element = driver.findElement(By.id("userPassword"));
				Log.info("Password text box is found on the Login page");
			} 
		catch (Exception e) 
			{
				Log.error("Password text box is not found on the Login Page");
				throw(e);
			}
		return element;
	}
	
	   public static WebElement btnLogIn() throws Exception{
       	try{
	        	element = driver.findElement(By.id("submitRelIdAuth"));
	            Log.info("Submit button is found on the Login page");
       		}
       	catch (Exception e)
       		{
       			Log.error("Submit button is not found on the Login Page");
          		throw(e);
          	}
          	return element;
       }

}
