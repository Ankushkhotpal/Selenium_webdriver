package com.appModules;
import org.testng.Reporter;

import com.pageObjects.LogIn_Page;

import com.utility.Constant;
import com.utility.ExcelUtils;
import com.utility.Log;
     
    
    public class SignIn_Action 
    {
    
        public static void Execute(int iTestCaseRow) throws Exception
        {

        	// Constant.Col_UserName is the column number for UserName column in the Test Data sheet
        	// Please see the Constant class in the Utility Package
        	String sUserName = ExcelUtils.getCellData(iTestCaseRow, Constant.Col_UserName);
        	
        	// Here we are sending the UserName string to the UserName Textbox on the LogIN Page
        	// This is call Page Object Model (POM)
            LogIn_Page.Username().sendKeys(sUserName);
            
            // Printing the logs for what we have just performed
            Log.info(sUserName+" is entered in UserName text box" );
            
            String sPassword = ExcelUtils.getCellData(iTestCaseRow, Constant.Col_Password);
            LogIn_Page.txtPassword().sendKeys(sPassword);
            Log.info(sPassword+" is entered in Password text box" );
            
            LogIn_Page.btnLogIn().click();
            Log.info("Click action is performed on Submit button");
            
            // I noticed in few runs that Selenium is trying to perform the next action before the complete Page load
            // So I have decided to put a wait on the Logout link element
            // Now it will wait 10 secs separately before jumping out to next step
           // Utils.waitForElement(LogIn_Page.lnk_LogOut());
          
            Reporter.log("SignIn Action is successfully perfomred");
            
        }
    }